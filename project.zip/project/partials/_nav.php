<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
    <!-- Brand/logo -->
    <a class="navbar-brand" href="#">
      <img src="2.png" alt="logo" style="width:60px; height:30px;">
    </a>
    
    <!-- Links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="/miniproject/home.php">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Contact Us</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">About Us</a>
      </li>
      
      
     <!-- <li>
     <div id="mySidenav" class="sidenav">
      <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
      <a href="info.html">Personal info</a>
      <a href="education.html">Education</a>
      <a href="#">Certifications & Internships</a>
      <a href="#">Academic Performance</a>
      <a href="/miniproject/logout.php">LogOut</a>
    </div>
    </li> -->
     
    </ul>
    
  </nav>